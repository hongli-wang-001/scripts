import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
import netCDF4

# Open the NetCDF file
filen = 'aod_viirs_hofx_2021022718.nc4'
path = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/gdas_app_crtm_n_rh/work_hofx/Data/hofx'
filename = path+filen

netcdf_file = netCDF4.Dataset(filename, 'r')

# Read latitude, longitude, and hofx data from the file
lat = netcdf_file.variables['lat'][:]
lon = netcdf_file.variables['lon'][:]
hofx = netcdf_file.variables['hofx'][:]

# Close the NetCDF file
netcdf_file.close()

# Create a figure and axes
fig, ax = plt.subplots(figsize=(10, 6))

# Create a Basemap instance for a global map
m = Basemap(projection='cyl', llcrnrlat=-90, urcrnrlat=90, llcrnrlon=-180, urcrnrlon=180, resolution='c', ax=ax)

# Convert latitude and longitude to map projection coordinates
x, y = m(lon, lat)

# Create a contour plot of hofx on the map
contour = m.contourf(x, y, hofx, cmap='viridis')

# Add coastlines, countries, and grid lines
m.drawcoastlines()
m.drawcountries()
m.drawparallels(np.arange(-90, 91, 30), labels=[1,0,0,0], linewidth=0.5, color='gray')
m.drawmeridians(np.arange(-180, 181, 60), labels=[0,0,0,1], linewidth=0.5, color='gray')

# Add a colorbar
cbar = m.colorbar(contour, location='right', pad='5%')
cbar.set_label('Quantity of hofx')

# Add a title
plt.title('Global Map of Quantity hofx')

# Show the plot
plt.show()
