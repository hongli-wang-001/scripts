import numpy as np
import matplotlib.pyplot as plt
from emcpy.plots.map_plots import MapGridded
from emcpy.plots import CreateFigure

# Your data loading and processing code remains unchanged...

# Create a MapGridded object
X, Y = np.meshgrid(lon, lat)
Z1 = aod1[0, :, :]
Z2 = aod2[0, :, :]
Zdiff = Z2 - Z1
gridded = MapGridded(Y, X, Zdiff)

# Set colorbar properties for the gridded data
gridded.colorbar = True
gridded.colorbar_label = 'AOD Difference'
gridded.cmap = 'jet'
gridded.vmin = -0.5
gridded.vmax = 0.5

# Create the figure
fig, ax = plt.subplots(subplot_kw={'projection': 'plcarr'})
gridded.plot(ax)

# Add colorbar for the gridded data
cbar = plt.colorbar(gridded, extend='both', orientation='horizontal', pad=0.05)
cbar.set_label('AOD Difference')

# Customize other plot settings as needed
ax.set_xlabel('longitude')
ax.set_ylabel('latitude')
ax.set_title('AOD Difference')

# Save or display the figure
figure_out = 'map_'+region+'_'+yymmdd_int+'_'+str(hour)+'_n20.png'
plt.savefig('test_plot_map_diff_'+yymmdd_int2+'_'+region+'_'+experiments[0]+'.png')
plt.show()
