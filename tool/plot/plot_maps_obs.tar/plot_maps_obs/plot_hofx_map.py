import numpy as np
import matplotlib.pyplot as plt
from emcpy.plots import CreatePlot, CreateFigure
from emcpy.plots.map_tools import Domain, MapProjection
from emcpy.plots.map_plots import MapScatter, MapGridded, MapContour
import datetime as dt 
from datetime import timedelta
import netCDF4 as nc

vmax= 0.25
region = 'global'
year = 2021 
month = 2 
day = 15 
yymmdd_int = str(year)+str(month).zfill(2)+str(day).zfill(2)
hour = 18 
experiments = ['exp_feb2021_noDA','exp_feb2021_feb_stddev1_inf']
#experiments = ['warm_start_lagged_seas_fix','cntrl_2wks']

experiment_path = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/python_wrappers/plot_omf/'
experiment_path_gocart = '/scratch1/NCEPDEV/stmp2/Andrew.Tangborn/gocart_files/'
date1=dt.datetime(year,month,day,hour)
date2=date1+dt.timedelta(hours=+6)
day2 = date2.strftime("%d")
hour2 = date2.hour
month2 = date2.month
year2 = date2.year
yymmdd_int2 = str(year2)+str(month2).zfill(2)+str(day2).zfill(2)

# Forecast files

fn_1= experiment_path_gocart+experiments[0]+'/gocart.inst_aod.'+str(yymmdd_int2)+'_'+str(hour2).zfill(2)+'00z.nc4'
fn_2= experiment_path_gocart+experiments[1]+'/gocart.inst_aod.'+str(yymmdd_int2)+'_'+str(hour2).zfill(2)+'00z.nc4'

variab1 = nc.Dataset(fn_1)
variab2 = nc.Dataset(fn_2)
lat=variab1.variables['lat'][:]
lon=variab1.variables['lon'][:]
nlat = len(lat)
nlon = len(lon)
print('lon=',lon)
print('shape.long=',np.shape(lon))
print('shape.lat=',np.shape(lat))
aod1 = variab1.variables['AOD'][:,:,:]
aod2 = variab2.variables['AOD'][:,:,:]
print('shape.aod1=',np.shape(aod1))

X,Y = np.meshgrid(lon,lat)
#Z1 = aod1[0,:,:]
#Z2 = aod2[0,:,:]
#Zdiff = Z2 - Z1
Zdiff = aod2 - aod1
time_step = 0
Zdiff_single_time_step = Zdiff[0,0, :, :]
print('Zdiff_single_time_step.shape=',Zdiff_single_time_step.shape)

X_flat = X.flatten()
Y_flat = Y.flatten()
Z_flat = Zdiff_single_time_step.flatten()

gridded = MapGridded(Y, X, Zdiff_single_time_step)
#gridded = MapGridded(Y,X, Zdiff)
print('shape.gridded=',np.shape(gridded))
gridded.cmap = 'jet'
gridded.vmin = -.5
gridded.vmax = 0.5




# Obs data

path_diag =  experiment_path+experiments[1]+'/gdas.'+str(year2)+str(month2).zfill(2)+str(day2).zfill(2)+'/'+str(hour2).zfill(2)+'/analysis/chem/'
file_n20 = 'diag_viirs_n20_'+str(year2)+str(month2).zfill(2)+str(day2).zfill(2)+str(hour2).zfill(2)+'.nc4'
file_npp = 'diag_viirs_npp_'+str(year2)+str(month2).zfill(2)+str(day2).zfill(2)+str(hour2).zfill(2)+'.nc4'
fn_n20 = path_diag+file_n20
fn_npp = path_diag+file_npp
qc_flag = 0
datain_n20 = nc.Dataset(fn_n20,'r')
datain_npp = nc.Dataset(fn_npp,'r')
meta_data_n20 = datain_n20.groups['MetaData']
meta_data_npp = datain_npp.groups['MetaData']
qc_group_n20 = datain_n20.groups['EffectiveQC2']
qc_group_npp = datain_npp.groups['EffectiveQC2']
bkgmob_group_n20 = datain_n20.groups['bkgmob']
bkgmob_group_npp = datain_npp.groups['bkgmob']
preqc_group_npp = datain_npp.groups['PreQC']
qc0_n20 = qc_group_n20.variables['aerosolOpticalDepth']
qc0_npp = qc_group_npp.variables['aerosolOpticalDepth']
omf1_n20 = bkgmob_group_n20.variables['aerosolOpticalDepth']
omf1_npp = bkgmob_group_npp.variables['aerosolOpticalDepth']
preqc = preqc_group_npp.variables['aerosolOpticalDepth']
lat1_n20 = meta_data_n20.variables['latitude']
lat1_npp = meta_data_npp.variables['latitude']

lon1_n20 = meta_data_n20.variables['longitude']
lon1_npp = meta_data_npp.variables['longitude']
lat_n20 = lat1_n20[:]
lat_npp = lat1_npp[:]
lon_n20 = lon1_n20[:]
lon_npp = lon1_npp[:]
omf_n20 = np.squeeze(omf1_n20,axis=1)
omf_npp = np.squeeze(omf1_npp,axis=1)
print('len(omf) = ', len(omf_npp))
qc_n20 = np.squeeze(qc0_n20,axis=1)
qc_npp = np.squeeze(qc0_npp,axis=1)
preqc = np.squeeze(preqc,axis=1)
print('qc_npp.shape=',qc_npp.shape)
print('qc_npp = ', qc_npp[1:30])
print('qc_flag = ', qc_flag)
lat_obs = lat_npp[qc_npp==qc_flag]
lon_obs = lon_npp[qc_npp==qc_flag]
omf_obs = omf_npp[qc_npp==qc_flag]
print(len(lat_obs),len(lon_obs),len(omf_obs))

scatter = MapScatter(latitude=lat_obs,longitude=lon_obs,data=omf_obs)
#scatter = MapScatter(latitude=lat_obs,longitude=lon_obs,data=preqc)
scatter.cmap = 'jet'
scatter.vmin = -0.5
scatter.vmax = 0.5 
scatter.markersize = 2 
# set colorbar=False so the gridded data is on colorbar


#plot1 = CreatePlot()
#plot1.plot_layers = [scatter]
#plot1.projection = 'plcarr'
#plot1.domain = region 
#plot1.add_map_features(['coastline'])
#plot1.add_xlabel(xlabel='longitude')
#plot1.add_ylabel(ylabel='latitude')
#plot1.add_title(label='Obs Data', loc='center')
#plot1.add_colorbar()

#fig = CreateFigure()
#fig.plot_list = [plot1]
#fig.colorbar(scatter, label='NPP O-F')

#fig.create_figure()
#figure_out = 'map_scatter_'+region+'_'+yymmdd_int+'_'+str(hour)+'_n20.png'
#fig.save_figure('test_plot_map_scatter_'+yymmdd_int2+'_'+region+'_'+experiments[0]+'.png')


plot2 = CreatePlot()
plot2.plot_layers = [gridded,scatter]
plot2.projection = 'plcarr'
plot2.domain = region
plot2.add_map_features(['coastline'])
plot2.add_xlabel(xlabel='longitude')
plot2.add_ylabel(ylabel='latitude')
plot2.add_title(label='DA - No DA', loc='center')

fig = CreateFigure()
fig.plot_list = [plot2]
fig.create_figure()
figure_out = 'map_'+region+'_'+yymmdd_int+'_'+str(hour)+'_n20.png'
fig.save_figure('test_plot_map_diff_'+yymmdd_int2+'_'+region+'_'+experiments[0]+'.png')

