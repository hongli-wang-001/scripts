import numpy as np
import matplotlib.pyplot as plt
from emcpy.plots import CreatePlot, CreateFigure
from emcpy.plots.map_tools import Domain, MapProjection
from emcpy.plots.map_plots import MapScatter, MapGridded, MapContour
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from matplotlib.colors import TwoSlopeNorm
import datetime as dt 
from datetime import timedelta
import netCDF4 as nc



vmin=-0.25
vmax= 0.25
region = 'global'
year = 2021 
month = 4 
day = 23 
yymmdd_int = str(year)+str(month).zfill(2)+str(day).zfill(2)
hour = 0 
experiments = ['exp_apr2021_jun_stddev10','exp_apr2021_noDA']
#experiments = ['warm_start_lagged_seas_fix','cntrl_2wks']

experiment_path = '/scratch1/NCEPDEV/stmp2/Andrew.Tangborn/gocart_files/'
date1=dt.datetime(year,month,day,hour)
date2=date1+dt.timedelta(hours=+6)
day2 = date2.strftime("%d")
hour2 = date2.hour
month2 = date2.month
year2 = date2.year
yymmdd_int2 = str(year2)+str(month2).zfill(2)+str(day2).zfill(2)

# Forecast files

fn_1= experiment_path+experiments[0]+'/gocart.inst_aod.'+str(yymmdd_int2)+'_'+str(hour2).zfill(2)+'00z.nc4'
fn_2= experiment_path+experiments[1]+'/gocart.inst_aod.'+str(yymmdd_int2)+'_'+str(hour2).zfill(2)+'00z.nc4'

variab1 = nc.Dataset(fn_1)
variab2 = nc.Dataset(fn_2)
lat=variab1.variables['lat'][:]
lon=variab1.variables['lon'][:]
print('lon=',lon)
print('shape.long=',np.shape(lon))
aod1 = variab1.variables['AOD'][:,:,:]
aod2 = variab2.variables['AOD'][:,:,:]
print('shape.aod1=',np.shape(aod1))

X,Y = np.meshgrid(lon,lat)
Z1 = aod1[0,0,:,:]
Z2 = aod2[0,0,:,:]
Zdiff = Z1 - Z2
print('shape.Zdiff = ', np.shape(Zdiff))
gridded = MapGridded(Y,X, Zdiff)
print('shape.gridded=',np.shape(gridded))
gridded.cmap = 'jet'
gridded.vmin = -.5
gridded.vmax = 0.5

# Set the color mapping
cmap = 'RdBu_r'  # Red-Blue colormap (you can choose other colormaps)
norm = TwoSlopeNorm(vmin=-0.5, vcenter=0, vmax=0.5)



# Obs data

path_diag =  '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/python_wrappers/plot_omf/'+experiments[0]+'/gdas.'+str(year2)+str(month2).zfill(2)+str(day2).zfill(2)+'/'+str(hour2).zfill(2)+'/analysis/chem/'
file_n20 = 'diag_viirs_n20_'+str(year2)+str(month2).zfill(2)+str(day2).zfill(2)+str(hour2).zfill(2)+'.nc4'
fn_n20 = path_diag+file_n20
qc_flag = 0
datain = nc.Dataset(fn_n20,'r')
meta_data = datain.groups['MetaData']
qc_group = datain.groups['EffectiveQC0']
bkgmob_group = datain.groups['bkgmob']
qc1 = qc_group.variables['aerosolOpticalDepth']
omf1 = bkgmob_group.variables['aerosolOpticalDepth']
lat1 = meta_data.variables['latitude']
lon1 = meta_data.variables['longitude']
lat = lat1[:]
lon = lon1[:]
omf = np.squeeze(omf1,axis=1)
print('len(omf) = ', len(omf))
qc = np.squeeze(qc1,axis=1)
print('qc = ', qc[:])
lat_obs = lat[qc==qc_flag]
lon_obs = lon[qc==qc_flag]
omf_obs = omf[qc==qc_flag]
print(len(lat_obs),len(lon_obs),len(omf_obs))


# Create a MapGridded object
X, Y = np.meshgrid(lon, lat)
Z1 = aod1[0,0, :, :]
Z2 = aod2[0,0, :, :]
Zdiff = Z1 - Z2
gridded = MapGridded(Y, X, Zdiff)

# Set colorbar properties for the gridded data
gridded.colorbar = True
gridded.colorbar_label = 'AOD Difference'
gridded.cmap = 'jet'
gridded.vmin = -0.5
gridded.vmax = 0.5

# Create the figure
fig, ax = plt.subplots(subplot_kw={'projection': ccrs.PlateCarree()})
img = ax.imshow(Zdiff, extent=(lon.min(), lon.max(), lat.min(), lat.max()), cmap='jet', origin='lower',norm=norm)

# Add continental outlines
ax.add_feature(cfeature.COASTLINE, linewidth=0.5, edgecolor='black')

#gridded.plot(ax)

# Add colorbar for the gridded data
cbar = plt.colorbar(img, extend='both', orientation='horizontal', pad=0.05)
cbar.set_label('AOD Difference')
# Customize other plot settings as needed
ax.set_xlabel('longitude')
ax.set_ylabel('latitude')
ax.set_title('AOD Difference')

# Save or display the figure
figure_out = 'map_'+region+'_'+yymmdd_int+'_'+str(hour)+'_n20.png'
plt.savefig('test_plot_map_diff_'+yymmdd_int2+'_'+region+'_'+experiments[0]+'.png')
plt.show()


