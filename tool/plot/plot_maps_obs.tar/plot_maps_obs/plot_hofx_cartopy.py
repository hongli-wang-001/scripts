import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import netCDF4

# Open the NetCDF file
filen = 'aod_viirs_hofx_2021022718.nc4'
#path = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/gdas_app_july28_2023/work_hofx/Data/hofx/'
path = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/gdas_app_nov14_2023/test_hofx/Data/hofx/'
filename = path+filen
netcdf_file = netCDF4.Dataset(filename, 'r')

# Read latitude, longitude, and hofx data from the file

lat_group = netcdf_file.groups['MetaData']
lat = lat_group.variables['latitude'][:]
lon = lat_group.variables['longitude'][:]

hofx_group = netcdf_file.groups['hofx']
hofx = hofx_group.variables['aerosolOpticalDepth'][:]
obs_group = netcdf_file.groups['ObsValue']
obs = obs_group.variables['aerosolOpticalDepth'][:] 
vmin = 0.0
vmax = 1.5 
# Close the NetCDF file
netcdf_file.close()

# Create a figure and axis using PlateCarree projection
fig, ax = plt.subplots(subplot_kw={'projection': ccrs.PlateCarree()}, figsize=(10, 6))

scatter = ax.scatter(lon, lat, c=hofx, cmap='viridis', s=10, transform=ccrs.PlateCarree(),vmin=vmin,vmax=vmax)

# Add coastlines and country borders
ax.add_feature(cfeature.COASTLINE)
ax.add_feature(cfeature.BORDERS, linestyle=':')

# Add grid lines
ax.gridlines(draw_labels=True, linestyle='--', color='gray')

# Add a colorbar
cbar = plt.colorbar(scatter, ax=ax, orientation='vertical', pad=0.05, label='AOD')

cbar.set_ticks([vmin, vmax])
cbar.set_ticklabels([vmin, vmax])
# Add a title
plt.title('hofx new bugfix' )

# Show the plot
plt.show()
