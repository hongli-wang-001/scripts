import numpy as np
import matplotlib.pyplot as plt
from emcpy.plots import CreatePlot, CreateFigure
from emcpy.plots.map_tools import Domain, MapProjection
from emcpy.plots.map_plots import MapScatter, MapGridded, MapContour
import datetime as dt
from datetime import timedelta
import netCDF4 as nc

# Your previous code...

# Obs data
# ... (the rest of your code)

lat_bin_edges = np.linspace(lat.min(), lat.max(), nlat + 1)
lon_bin_edges = np.linspace(lon.min(), lon.max(), nlon + 1)

# Use numpy.histogram2d to bin the data
hist, lat_edges, lon_edges = np.histogram2d(lat_obs, lon_obs, bins=[lat_bin_edges, lon_bin_edges])

# Compute the sum of omf_obs in each bin
omf_sum = np.histogram2d(lat_obs, lon_obs, bins=[lat_bin_edges, lon_bin_edges], weights=omf_obs)[0]

# Compute the count of observations in each bin
count = np.histogram2d(lat_obs, lon_obs, bins=[lat_bin_edges, lon_bin_edges])[0]

# Avoid division by zero by setting count to 1 where it's zero
count[count == 0] = 1

# Compute the average omf_obs in each bin
omf_avg = omf_sum / count

# Create a gridded map of the average values
avg_gridded = MapGridded(lat_edges[:-1], lon_edges[:-1], omf_avg)

# Plot the average gridded data
plot_avg = CreatePlot()
plot_avg.plot_layers = [avg_gridded]
plot_avg.projection = 'plcarr'
plot_avg.domain = region
plot_avg.add_map_features(['coastline'])
plot_avg.add_xlabel(xlabel='longitude')
plot_avg.add_ylabel(ylabel='latitude')
plot_avg.add_title(label='Average Obs Data', loc='center')
plot_avg.add_colorbar()

# Add the average gridded plot to the existing figure
fig.plot_list.append(plot_avg)
