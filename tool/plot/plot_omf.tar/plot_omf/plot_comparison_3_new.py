import numpy as np
import os
from pathlib import Path
import math
import matplotlib.pyplot as plt
import subprocess as sp
#import matplotlib.pyplot as plt
#from emcpy.plots import CreateMap
#from emcpy.plots.map_tools import Domain, MapProjection
#from emcpy.plots.map_plots import MapGridded
import netCDF4 as nc
import glob
import array
import tarfile
import time



domain = 'global'
exp_name = ['lagged_forecast_feb2021','exp_feb2021_stddev10n','exp_feb2021_noDA']
exp_title = ['stddev10','sin','noDA']
file = [' ',' ']
print('exp_name=',exp_name) 
year = 2021 
month_list = [2]
day_list = [[0]*3]*2
#print('len(day_list) = ', len(day_list))
day_list = [[1,2,3,4,5]]#,16,17,18,19,20,21,22,23,24,25,26,27]]#,[1,2,3,4,5,6,7,8,9,10]]
hour_list = [0, 6, 12, 18]

if domain == 'northern_hemisphere':
   lat_min = 0
   lat_max = 90
   lon_min = -180 
   lon_max = 180 
if domain == 'northeast_quadrasphere':
   lat_min = 0
   lat_max = 90
   lon_min = 0 
   lon_max = 180
if domain == 'northwest_quadrasphere':
   lat_min = 0 
   lat_max = 90 
   lon_min = -180
   lon_max = 0
if domain == 'southern_hemisphere':
   lat_min = -90
   lat_max = 0 
   lon_min = -180
   lon_max = 180 
if domain == 'conus':
   lat_min = 25
   lat_max = 60 
   lon_min = -135
   lon_max = -80 
if domain == 'conus_west':
   lat_min = 25
   lat_max = 60
   lon_min = -135 
   lon_max = -110
if domain == 'conus_east':
   lat_min = 25
   lat_max = 60
   lon_min = -110 
   lon_max = -80
if domain == 'canada':
   lat_min = 54 
   lat_max = 75
   lon_min = - 135
   lon_max = - 60
elif domain == 'europe':
   lat_min = 30
   lat_max = 72
   lon_min = 8
   lon_max = 40
elif domain == 'africa':
   lat_min = -50
   lat_max =  30 
   lon_min = -10 
   lon_max =  50 
elif domain == 'west_africa':
   lat_min = -15
   lat_max =  10
   lon_min =  10
   lon_max =  30
elif domain == 'north_africa':
   lat_min =  10
   lat_max =  35
   lon_min = -10
   lon_max =  45
elif domain == 'east_asia':
   lat_min =  20
   lat_max =  40
   lon_min = 105
   lon_max = 140
elif domain == 'southern_ocean':
   lat_min = -90
   lat_max = -45
   lon_min = -180
   lon_max =  180
elif domain == 'arctic':
   lat_min = 60 
   lat_max = 90
   lon_min = -180
   lon_max = 180 
elif domain == 'southern_mid_lat':
   lat_min = -55
   lat_max = -30
   lon_min = -180
   lon_max = 180
elif domain == 'tropics':
   lat_min = -23
   lat_max =  23
   lon_min = -180
   lon_max = 180
elif domain == 'northern_mid_lat':
   lat_min = 30 
   lat_max = 55 
   lon_min = -180
   lon_max = 180
elif domain == 'south_america':
   lat_min = -60 
   lat_max =  10 
   lon_min = -80
   lon_max = -35 

   
elif domain == 'global':
   lat_min = -90
   lat_max = 90
   lon_min = -180
   lon_max = 180



#print('day_list=',day_list)
#print('day_list[0][0]=',day_list[0][0])
#print('day_list[0][:]=',day_list[0][:])
#ncyc=(len(day_list[0][:])+len(day_list[1][:]))*len(hour_list)
#nday=len(day_list[0][:])+len(day_list[1][:])
ncyc=(len(day_list[0][:]))*len(hour_list)
nday=len(day_list[0][:])
nexp = len(exp_name)
omf_day = []
oma_day = [] 
print('nday=',nday)
mean_omf_day_all = np.zeros([nexp,nday])
mean_oma_day_all = np.zeros([nexp,nday])
std_omf_day_all = np.zeros([nexp,nday])
std_oma_day_all = np.zeros([nexp,nday])
print('mean_omf_day_all.size=',mean_omf_day_all.size)

mean_omf_all = np.zeros([nexp,ncyc])
std_omf_all = np.zeros([nexp,ncyc])
mean_oma_all = np.zeros([nexp,ncyc])
std_oma_all = np.zeros([nexp,ncyc])
mean_omf_all_npp = np.zeros([nexp,ncyc])
std_omf_all_npp = np.zeros([nexp,ncyc])
mean_oma_all_npp = np.zeros([nexp,ncyc])
std_oma_all_npp = np.zeros([nexp,ncyc])
cyc_num = np.zeros([nexp,ncyc])
iexp=0
while iexp < len(exp_name):
   print('exp_name=',exp_name[iexp])
#   print('len(exp_name) = ', len(exp_name))
   if exp_name[iexp] == 'cntrl_2wks':
      qc_flag = 0 
   elif exp_name[iexp] == 'cntrl_2021':
      qc_flag = 0 
   else:
      qc_flag = 0
   if exp_name[iexp] == 'lagged_staticb':
     aero_var = 'aerosolOpticalDepth'
   elif exp_name[iexp] == 'lagged_staticb_seas_div10':
     aero_var = 'aerosolOpticalDepth'
   elif exp_name[iexp] == 'warm_start_lagged_seas_fix':
     aero_var = 'aerosolOpticalDepth'
   elif exp_name[iexp] == 'lagged_cor_0p5':
     aero_var = 'aerosolOpticalDepth'
   elif exp_name[iexp] =='spinup_july20_aug1_2021':
     aero_var = 'aerosolOpticalDepth'
   elif exp_name[iexp] =='lagged_forecast_feb2021':
     aero_var = 'aerosolOpticalDepth'
   elif exp_name[iexp] =='cntrl_2021':
     aero_var = 'aerosolOpticalDepth'
   elif exp_name[iexp] =='stddev10_mod_2021':
     aero_var = 'aerosolOpticalDepth'
   elif exp_name[iexp] =='exp_feb2021_staticb_lagged_aug21':
     aero_var = 'aerosolOpticalDepth'
   elif exp_name[iexp] =='exp_feb2021_noDA':
     aero_var = 'aerosolOpticalDepth'
   elif exp_name[iexp] =='lagged_forecast_feb2021':
     aero_var = 'aerosolOpticalDepth'
   elif exp_name[iexp] =='exp_feb2021_stddev2':
     aero_var = 'aerosolOpticalDepth'
   elif exp_name[iexp] =='exp_feb2021_sin':
     aero_var = 'aerosolOpticalDepth'
   else:
     aero_var = 'aerosol_optical_depth'
       
#   print('aero_var = ', aero_var)
   icyc=0
   iday=0
   for month in month_list:
#      print('month=',month)
      for day in day_list[month-2][:]:
         print('day= ',day)
         for hour in hour_list:
            print('hour=',hour)
            yyyymmddhh_str = str(year)+str(month).zfill(2)+str(day).zfill(2)+str(hour).zfill(2)
            yyyymmdd_str = str(year)+str(month).zfill(2)+str(day).zfill(2)
            if exp_name[iexp] == 'lagged_staticb' or exp_name[iexp] == 'lagged_staticb_seas_div10' or exp_name[iexp] == 'warm_start_lagged_seas_fix' or exp_name[iexp] == 'lagged_cor_0p5' or exp_name[iexp] == 'spinup_july20_aug1_2021' or exp_name[iexp] == 'lagged_forecast_feb2021' or exp_name[iexp] == 'cntrl_2021' or exp_name[iexp] == 'stddev10_mod_2021' or exp_name[iexp] =='exp_feb2021_staticb_lagged_aug21' or exp_name[iexp] == 'exp_feb2021_noDA' or exp_name[iexp] == 'lagged_forecast_feb2021' or exp_name[iexp] == 'exp_feb2021_stddev2'or exp_name[iexp] =='exp_feb2021_sin': 
              #data_path = '/scratch1/NCEPDEV/stmp2/Andrew.Tangborn/ROTDIR/'+exp_name[iexp]+'/gdas.'+str(year)+str(month).zfill(2)+str(day).zfill(2)+'/'+str(hour).zfill(2)+'/chem/scratch1/NCEPDEV/stmp2/Andrew.Tangborn/RUNDIRS/'+exp_name[iexp]+'/gdasaeroanl_'+str(hour).zfill(2)+'/diags/'
              data_path = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/python_wrappers/plot_omf/'+exp_name[iexp]+'/gdas.'+yyyymmdd_str+'/'+str(hour)+'/analysis/chem/'
              filename = 'diag_viirs_n20_'+yyyymmddhh_str+'.nc4'
              filename_npp = 'diag_viirs_npp_'+yyyymmddhh_str+'.nc4'
#              print('filename=',filename)
              fn = Path(data_path+filename)
              if exp_name[iexp] == 'exp_forecast2021_stddev2':
                  print('fn=',fn) 
              
              fn_npp = Path(data_path+filename)
            else: 
              data_path = '/scratch1/NCEPDEV/stmp2/Andrew.Tangborn/ROTDIR/'+exp_name[iexp]+'/gdas.'+str(year)+str(month).zfill(2)+str(day).zfill(2)+'/'+str(hour).zfill(2)+'/chem/scratch1/NCEPDEV/stmp2/Andrew.Tangborn/RUNDIRS/'+exp_name[iexp]+'/'+str(year)+str(month).zfill(2)+str(day).zfill(2)+str(hour).zfill(2)+'/gdas/aeroanl_'+str(year)+str(month).zfill(2)+str(day).zfill(2)+str(hour).zfill(2)+'/diags/'
              filename = 'diag_viirs_n20_'+yyyymmddhh_str+'_0000.nc4'
              filename_npp = 'diag_viirs_npp_'+yyyymmddhh_str+'_0000.nc4'
#            print('filename=',filename)
            fn = Path(data_path+filename)
            fn_npp = Path(data_path+filename) 
#            print('fn=',fn) 
            if exp_name[iexp] == 'exp_feb2021_stddev2':
               print('fn.exists=',fn.exists())
            if fn.exists():
               if exp_name[iexp] == 'exp_feb2021_stddev2':
                  print('fn=',fn)
               datain = nc.Dataset(fn,'r') 
               datain_npp = nc.Dataset(fn_npp,'r')
               meta_data = datain.groups['MetaData']
               bkgmob_group = datain.groups['bkgmob']
               anlmob_group= datain.groups['anlmob']
               qc_group = datain.groups['PreQC']
               bkgmob_group_npp = datain_npp.groups['bkgmob']
               anlmob_group_npp = datain_npp.groups['anlmob']
               qc_group_npp = datain_npp.groups['PreQC']
               omf1 = bkgmob_group.variables[aero_var]
#               print('omf1=',omf1)
               oma1 = anlmob_group.variables[aero_var]
               qc1 = qc_group.variables[aero_var]
               lat1 = meta_data.variables['latitude']
               lon1 = meta_data.variables['longitude']
               qc = np.squeeze(qc1,axis=1)
               omf = np.squeeze(omf1,axis=1)
               oma = np.squeeze(oma1,axis=1)
#               print('omf= ',omf)
               lat2 = lat1[:] #np.squeeze(lat1,axis=1)
               lon2 = lon1[:] # np.squeeze(lon1,axis=1)
#               print('qc_shape=',qc.shape)
#               print('omf_shape=',omf.shape)
#               print('len(qc)=',len(qc))
#               print('omf[0:20] = ', omf[0:20])
#               print('oma[0:20] = ', oma[0:20])
#               print('qc[0:20] = ', qc[0:20])
#               print('qc_flag=',qc_flag)
               lat = lat2[qc==qc_flag]
               lon = lon2[qc==qc_flag]
               omf = omf[qc==qc_flag]
               oma = oma[qc==qc_flag]
#               print('after qc_flag, omf = ', omf[0:20])
#               print('qc_shape=', qc.shape)
#               print('qc_max=', max(qc))
#               print('qc_min=', min(qc))
#               print('omf_shape=', omf.shape)
               omf = omf[lat > lat_min]
               oma = oma[lat > lat_min]
               lon = lon[lat > lat_min]
               lat = lat[lat > lat_min]
               
               omf = omf[ lat < lat_max] # & lat < 60 & lat > 25 & lon < -60 & lon > -130]
               oma = oma[lat < lat_max] # & lat < 60 & lat > 25 & lon < -60 & lon > -130]
               lon = lon[lat < lat_max]
               lat = lat[lat < lat_max] 
               omf = omf[lon > lon_min]
               oma = oma[lon > lon_min]
               lon = lon[lon > lon_min]
#               lat = lat[lon > lon_min]
               omf = omf[lon < lon_max]
               oma = oma[lon < lon_max]
               if hour == 0:
                 omf_day = []
                 omf_day = []
                 omf_day = omf
                 oma_day = oma
                 
               elif len(omf>0):
#                 print('hour= ', hour)
#                 print('omf_day= ',omf_day)
#                 print('omf= ',omf)
                 omf_day = np.concatenate((omf_day,omf),axis=None) 
                 oma_day = np.concatenate((oma_day,oma),axis=None)
                 if exp_name[iexp] == 'exp_feb2021_stddev2':
                    print('omf_day = ', omf_day[1:10])
   
             
               
               omf_npp1 = bkgmob_group_npp.variables[aero_var]
               oma_npp1 = anlmob_group_npp.variables[aero_var]
               omf_npp = np.squeeze(omf_npp1, axis=1)
               oma_npp = np.squeeze(oma_npp1, axis=1)
               qc1_npp = qc_group_npp.variables[aero_var]
               qc_npp = np.squeeze(qc1_npp,axis=1)
#               print('array shapes = ',omf_npp.shape, qc.shape)
#               print('qc==0: ', qc[qc==0])
               
#               print('omf_npp[0:10]=',omf_npp[len(omf_npp)-1])
#               print('qc = ',qc)
#               print('qc_flag = ', qc_flag)
#               print('len(qc) = ', len(qc)) 
#               print('len(omf_npp) = ', len(omf_npp))
#               print(qc[0:10]) 
#               print('qc==qc_flag ',qc==qc_flag)
               omf_npp = omf_npp[qc==qc_flag] #& lat < 60 & lat > 25 & lon < -60 & lon > -130]
               oma_npp = oma_npp[qc==qc_flag] # & lat < 60 & lat > 25 & lon < -60 & lon > -130]
#               print('omf_npp shape =', omf_npp.shape)
#               print('omf_npp = ', omf_npp[0:10])
               lat_npp = lat2[qc_npp==qc_flag]
               lon_npp = lon2[qc_npp==qc_flag]
#               omf_npp = omf_npp[lat_npp > 25.]
#               oma_npp = oma_npp[lat_npp > 25.]
               if iexp==0:
                  print('omf=',omf)
                  
               mean_omf = 0
               mean_oma = 0 
               std_omf = 0 
               std_oma = 0
               mean_omf = np.nanmean(omf)
               mean_oma = np.nanmean(oma)
#               print('mean_omf = ', mean_omf)
#               print('mean_oma = ', mean_oma)
               std_omf = np.nanstd(omf)
               std_oma = np.nanstd(oma)
               
               mean_omf_npp = 0
               mean_oma_npp = 0 
               std_omf_npp = 0
               std_oma_npp = 0 
               mean_omf_npp = np.nanmean(omf_npp)
               mean_oma_npp = np.nanmean(oma_npp)
               std_omf_npp = np.nanstd(omf_npp)
               std_oma_npp = np.nanstd(oma_npp)
#               print('icyc= ', iexp,'icyc= ',icyc)
#               print('mean_omf_all.shape = ', mean_omf_all.shape) 
               mean_omf_all[iexp,icyc] = mean_omf
               mean_oma_all[iexp,icyc] = mean_oma
               std_omf_all[iexp,icyc] = std_omf
               std_oma_all[iexp,icyc] = std_oma
               mean_omf_all_npp[iexp,icyc] = mean_omf_npp
               mean_oma_all_npp[iexp,icyc] = mean_oma_npp
               std_omf_all_npp[iexp,icyc] = std_omf_npp
               std_oma_all_npp[iexp,icyc] = std_oma_npp
#               print(iexp,icyc,'mean_omf_all[iexp,icyc]= ',mean_omf_all[iexp,icyc])
         
               icyc+=1 
         mean_omf_day = 0.0
         mean_oma_day = 0.0
         std_omf_day = 0.0
         std_oma_day = 0.0 
         mean_omf_day = np.nanmean(omf_day)
         if exp_name[iexp] == 'exp_feb2021_stddev2':
             print('omf_day = ',omf_day[0:10])
             print('mean_omf_day = ',mean_omf_day)
         mean_oma_day = np.nanmean(oma_day)
         std_omf_day = np.nanstd(omf_day)
         std_oma_day = np.nanstd(oma_day)
         mean_omf_day_all[iexp,iday] = mean_omf_day
         mean_oma_day_all[iexp,iday] = mean_oma_day
         std_omf_day_all[iexp,iday] = std_omf_day
         std_oma_day_all[iexp,iday] = std_oma_day
         iday = iday+1
         print('iday=',iday)
   iexp+=1


const_zero = np.zeros(icyc)
const_zero_day = np.zeros(nday)
#print('length(mean_omf_all)=',len(mean_omf_all[0,:]))
#plt.figure(0)
#plt.plot( mean_omf_all[0,0:len(mean_omf_all[0,:]-2)],"-b",label="Mean OmF "+exp_title[0],linewidth=1.0)
#plt.plot( mean_oma_all[0,0:len(mean_oma_all[0,:]-2)],"-r",label="Mean OmA "+exp_name[0],linewidth=1.0)
#plt.plot( std_omf_all[0,0:len(std_omf_all[0,:]-2)],"-.b",label="Std OmF "+exp_title[0], linewidth=1.0)
#plt.plot(std_oma_all[0,0:len(std_omf_all[0,:]-2)],"-.r",label="Std OmA "+exp_name[0], linewidth=1.0)
#plt.plot( mean_omf_all[1,0:len(mean_omf_all[1,:]-2)],"-g",label="Mean OmF "+exp_title[1],linewidth=1.0)
#plt.plot( mean_oma_all[1,0:len(mean_oma_all[1,:]-2)],"-m",label="Mean OmA "+exp_name[1],linewidth=1.0)
#plt.plot( std_omf_all[1,0:len(std_omf_all[1,:]-2)],"-.g",label="Std OmF "+exp_title[1], linewidth=1.0)
#plt.plot(std_oma_all[1,0:len(std_omf_all[1,:]-2)],"-.m",label="Std OmA "+exp_name[1], linewidth=1.0)
#plt.plot( const_zero[:],"-.k",linewidth=.5)
#plt.xlabel("Cycle")
#plt.ylabel("Mean (Std)")# OmF(OmA)")
#plt.legend(loc="lower left", prop={'size':6})
#plt.savefig('omf_stats_'+exp_name[0]+'_'+exp_name[1]+'_'+domain+'.png')

#plt.figure(1)
#plt.plot( mean_omf_all_npp[0,0:len(mean_omf_all[0,:]-2)],"-b",label="Mean OmF "+exp_title[0],linewidth=1.0)
#plt.plot( mean_oma_all_npp[0,0:len(mean_oma_all[0,:]-2)],"-r",label="Mean OmA "+exp_name[0],linewidth=1.0)
#plt.plot( std_omf_all_npp[0,0:len(std_omf_all[0,:]-2)],"-.b",label="Std OmF "+exp_title[0], linewidth=1.0)
#plt.plot(std_oma_all_npp[0,0:len(std_omf_all[0,:]-2)],"-.r",label="Std OmA "+exp_name[0], linewidth=1.0)
#plt.plot( mean_omf_all_npp[1,0:len(mean_omf_all[1,:]-2)],"-g",label="Mean OmF "+exp_title[1],linewidth=1.0)
#plt.plot( mean_oma_all_npp[1,0:len(mean_oma_all[1,:]-2)],"-m",label="Mean OmA "+exp_name[1],linewidth=1.0)
#plt.plot( std_omf_all_npp[1,0:len(std_omf_all[1,:]-2)],"-.g",label="Std OmF "+exp_title[1], linewidth=1.0)
#plt.plot(std_oma_all_npp[1,0:len(std_omf_all[1,:]-2)],"-.m",label="Std OmA "+exp_name[1], linewidth=1.0)
#plt.plot( const_zero[:],"-.k",linewidth=.5)
#plt.xlabel("Cycle")
#plt.ylabel("Mean (Std)")# OmF(OmA)")
#plt.legend(loc="lower left", prop={'size':6})
#plt.savefig('omf_stats_'+exp_name[0]+'_'+exp_name[1]+'_npp_'+domain+'.png')

print('mean_omf_day_all[0,:]=',mean_omf_day_all[0,:])
print('mean_omf_day_all[1,:]=',mean_omf_day_all[1,:])
print('mean_omf_day_all[2,:]=',mean_omf_day_all[2,:])

plt.figure(1)
plt.plot(mean_omf_day_all[0,0:len(mean_omf_day_all[0,:]-2)],"-b",label="Mean OmF "+exp_title[0],linewidth=1.0)
plt.plot(mean_oma_day_all[0,0:len(mean_oma_day_all[0,:]-2)],"-r",label="Mean OmA "+exp_title[0],linewidth=1.0)
plt.plot( std_omf_day_all[0,0:len(std_omf_day_all[0,:]-2)],"-.b",label="Std OmF "+exp_title[0], linewidth=1.0)
plt.plot( std_oma_day_all[0,0:len(std_oma_day_all[0,:]-2)],"-.r",label="Std OmA "+exp_title[0], linewidth=1.0)
plt.plot( mean_omf_day_all[1,0:len(mean_omf_day_all[1,:]-2)],"-c",label="Mean OmF "+exp_title[1],linewidth=1.0)
plt.plot(mean_oma_day_all[1,0:len(mean_oma_day_all[1,:]-2)],"-m",label="Mean OmA "+exp_title[1],linewidth=1.0)
plt.plot( std_omf_day_all[1,0:len(std_omf_day_all[1,:]-2)],"-.c",label="Std OmF "+exp_title[1], linewidth=1.0)
plt.plot( std_oma_day_all[1,0:len(std_oma_day_all[1,:]-2)],"-.m",label="Std OmA "+exp_title[1], linewidth=1.0)
plt.plot( mean_omf_day_all[2,0:len(mean_omf_day_all[2,:]-2)],"-g",label="Mean OmF "+exp_title[2],linewidth=1.0)
plt.plot( std_omf_day_all[2,0:len(std_omf_day_all[2,:]-2)],"-.g",label="Std OmF "+exp_title[2], linewidth=1.0)
plt.plot( const_zero_day[:],"-.k",linewidth=.5)
plt.xlabel("Day")
plt.ylabel("Mean (Std)")# OmF(OmA)")
plt.legend(loc="upper left", prop={'size':6})
plt.savefig('omf_stats_'+exp_name[0]+'_'+exp_name[1]+'_n20_'+domain+'.png')
