import numpy as np
import os
from pathlib import Path
import math
import matplotlib.pyplot as plt
import subprocess as sp
#import matplotlib.pyplot as plt
#from emcpy.plots import CreateMap
#from emcpy.plots.map_tools import Domain, MapProjection
#from emcpy.plots.map_plots import MapGridded
import netCDF4 as nc
#fn = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/gdas_app_july28_2023/work_aero_c96/Data/hofx_stddev10_rm_nan/aod_viirs_3dvar_gfs_aero_n20_2021022718.nc4'
#fn = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/gdas_app_april9_2024/test_3dvar_c96/Data/hofx_rs20/viirs_3dvar_gfs_aero_2021033118.nc4'
fn = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/diffusion_experiment/aod_viirs_3dvar_gfs_aero_2021033118.nc4'
#fn = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/gdas_app_march8_2023/work_3dvar_c96/Data/hofx/aod_viirs_n20_3dvar_gfs_aero_2021080112.nc4'
#fn = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/gdas_app_july28_2023/work_aero_c96/Data/hofx_stddev10_corhp5/aod_viirs_3dvar_gfs_aero_n20_2021022718.nc4'
datain = nc.Dataset(fn,'r')
meta_data = datain.groups['MetaData']
ombg_group = datain.groups['ombg']
oman_group= datain.groups['oman']
qc_group = datain.groups['PreQC']
omf1 = ombg_group.variables['aerosolOpticalDepth']
oma1 = oman_group.variables['aerosolOpticalDepth']
qc1 = qc_group.variables['aerosolOpticalDepth']
lat1 = meta_data.variables['latitude']
lon1 = meta_data.variables['longitude']
xx = np.array([-2, 5])
yy = np.array([-2, 5])
abs_omf = [abs(x) for x in omf1]
abs_oma = [abs(x) for x in oma1]

print('mean(abs(omf)) = ',np.nanmean(abs_omf))
print('mean(abs(oma)) = ',np.nanmean(abs_oma))
print('mean omf = ',np.nanmean(omf1))
print('mean oma = ',np.nanmean(oma1))
print('std omf = ', np.nanstd(omf1))
print('std oma = ', np.nanstd(oma1))

plt.figure(1)
plt.plot(oma1,"-r",label="OmA ",linewidth=0.5)
plt.plot(omf1,"-b",label="OmF ",linewidth=0.5)
plt.xlabel("obs")
plt.ylabel("OmF (OmA)")
plt.legend(loc="upper left", prop={'size':6})
plt.savefig('omf_stddev10_rm_nan.png')


plt.figure(2)
plt.plot(omf1,oma1,'b.')
plt.plot(xx,yy,'--k')
plt.savefig('scatter_stddev10_corhp1.png')
