import numpy as np
import os
from pathlib import Path
import math
import matplotlib.pyplot as plt
import subprocess as sp
#import matplotlib.pyplot as plt
#from emcpy.plots import CreateMap
#from emcpy.plots.map_tools import Domain, MapProjection
#from emcpy.plots.map_plots import MapGridded
import netCDF4 as nc
#fn1 = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/gdas_app_july28_2023/work_aero_c96/Data/hofx_stddev10_rm_nan/aod_viirs_3dvar_gfs_aero_n20_2021022718.nc4'
fn1 = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/gdas_app_july28_2023/work_hofx/Data/hofx/aod_viirs_hofx_2021022718.nc4'
fn2 = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/gdas_app_crtm_n_rh/work_hofx/Data/hofx/aod_viirs_hofx_2021022718.nc4'
#fn = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/gdas_app_march8_2023/work_3dvar_c96/Data/hofx/aod_viirs_n20_3dvar_gfs_aero_2021080112.nc4'
#fn = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/gdas_app_july28_2023/work_aero_c96/Data/hofx_stddev10_corhp5/aod_viirs_3dvar_gfs_aero_n20_2021022718.nc4'
datain_1 = nc.Dataset(fn1,'r')
datain_2 = nc.Dataset(fn2,'r')
hofx_group_1 = datain_1.groups['hofx']
hofx_group_2 = datain_2.groups['hofx']
hofx_1 = hofx_group_1.variables['aerosolOpticalDepth']
hofx_2 = hofx_group_2.variables['aerosolOpticalDepth'] 
print('hofx_1 = ',hofx_1[0:10])
print('hofx_2 = ',hofx_2[0:10])
plt.plot(hofx_1, hofx_2,'.')
plt.xlabel('CRTM 2.3')
plt.ylabel('CRTM 2.4 bugfix')
plt.title('Hofx for all species')
plt.show()

