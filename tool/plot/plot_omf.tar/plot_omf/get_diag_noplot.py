import numpy as np
import os 
from pathlib import Path
import math
import matplotlib.pyplot as plt
import subprocess as sp
#import matplotlib.pyplot as plt
#from emcpy.plots import CreateMap
#from emcpy.plots.map_tools import Domain, MapProjection
#from emcpy.plots.map_plots import MapGridded
import netCDF4 as nc
import glob
import array
import tarfile 
import time 


datapath = '/scratch1/NCEPDEV/da/Andrew.Tangborn/JEDI/python_wrappers/plot_omf'
#exp_name = 'exp_apr2021_jun_stddev10_C96_C192'
#exp_name = 'exp_feb2021_feb_stddev1_inf'
exp_name = 'aerob_april_2021_rs20'
year = 2021
month = 4 
#day_list = [13,14] 
day_list = [1,2]#,14,15,16]
hour_list = [0,6,12,18]
#hour = 6
ncyc=len(day_list)*len(hour_list)-1 
mean_omf_all = np.zeros(ncyc+1)
std_omf_all = np.zeros(ncyc+1)
mean_oma_all = np.zeros(ncyc+1)
std_oma_all = np.zeros(ncyc+1)
mean_omf_all_npp = np.zeros(ncyc+1)
std_omf_all_npp = np.zeros(ncyc+1)
mean_oma_all_npp = np.zeros(ncyc+1)
std_oma_all_npp = np.zeros(ncyc+1)
cyc_num = np.zeros(ncyc+1) 

my_env = os.environ.copy()
my_env['OMP_NUM_THREADS'] = '4' # for openmp to speed up fortran call

#icyc=0
#mean_omf = []
#mean_oma = [] 
#std_omf = []
#std_oma = [] 

#if exp_name == 'cntrl_pass':
#  qc_flag = 13
#else:
#  qc_flag = 0

for day in day_list: 
   for hour in hour_list:
      print('hour = ', hour) 
      chem_path = datapath+'/'+exp_name+'/gdas.'+str(year)+str(month).zfill(2)+str(day).zfill(2)+'/'+str(hour).zfill(2)+'/analysis/chem/'
      tardir = datapath+'/'+exp_name+'/gdas.'+str(year)+str(month).zfill(2)+str(day).zfill(2)+'/'+str(hour).zfill(2)+'/analysis/chem/'
      print('chem_path= ',chem_path)
      print('tardir = ', tardir)
      tar_file = tardir+'/gdas.t'+str(hour).zfill(2)+'z.aerostat'
      print('tar_file=',tar_file)
# Check if tar file exists
      myfile_tar = Path(tar_file)
      if myfile_tar.exists():
# Determine path to tar diag file  
         cmd = 'tar -tf '+tar_file
         print(' cmd = ', cmd) 
         proc = sp.Popen(cmd,env=my_env,shell=True,stdout=sp.PIPE)
         output = proc.stdout.read()
         len1 = int(len(output)/2)
         output1 = output[0:len1]
         output_npp = output[len1:len(output)] 
         print('output_npp = ', output_npp)
         output1a = output1.strip()
         output_npp_a = output_npp.strip()
         print('output_npp_a =', output_npp_a)
         print('output1a=',output1a)
         my_env = os.environ.copy()
         my_env['OMP_NUM_THREADS'] = '4' 
         cmd2 = 'tar -xvf '+tar_file+' -C ' +tardir
         print('cmd2 = ', cmd2) 
         proc2 = sp.Popen(cmd2,env=my_env,shell=True,stdout=sp.PIPE) 
         output2 = proc2.stdout.read()
         print('output2=',output2)
#   os.system(cmd2) 
#   os.system('ls')
# Path and filename of O-F stats file. 
         fn=chem_path+output1a.decode("utf-8")
         fn_npp = chem_path+output_npp_a.decode("utf-8") 
         print('output1a= ',output1a)
         
         print('fn= ',fn)
         print('fn_npp= ',fn_npp)
         myfile = Path(fn) 
         if myfile.exists():
            print(fn,' exists')
            cmd3 = 'gunzip '+fn 
            cmd4 = 'gunzip '+fn_npp
            sp.Popen(cmd3,env=my_env,shell=True)
            sp.Popen(cmd4,env=my_env,shell=True)
         fn_nc_tmp = fn[0:len(fn)-3]
         fn_nc = str(fn_nc_tmp)
         fn_npp_tmp = fn_npp[0:len(fn_npp)-3]
         fn_npp = str(fn_npp_tmp) 
         res = isinstance(fn_nc, str)
         print('fn_nc = ', fn_nc) 
         if res:
           print('fn_nc_1=',fn_nc)
         else:
           fn_nc = fn[0:len(fn)-3].decode("utf-8")
           fn_npp = fn_npp[0:len(fn_npp)-3].decode("utf-8")
           print('fn_nc_2=',fn_nc) 
   
         print('fn_nc=',fn_nc) 
         ncfile = Path(fn_nc)
         if ncfile.exists():
            datain = nc.Dataset(fn_nc,'r')
            datain_npp = nc.Dataset(fn_npp,'r')
         else:
            time.sleep(30)
            datain = nc.Dataset(fn_nc,'r')
            datain_npp = nc.Dataset(fn_npp,'r')
            
         

