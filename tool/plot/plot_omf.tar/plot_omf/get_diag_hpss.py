import numpy as np
import os 
from pathlib import Path
import math
#import matplotlib.pyplot as plt
import subprocess as sp
#import matplotlib.pyplot as plt
#from emcpy.plots import CreateMap
#from emcpy.plots.map_tools import Domain, MapProjection
#from emcpy.plots.map_plots import MapGridded
import netCDF4 as nc
import glob
import array
import tarfile 
import time 

datapath = '/NCEPDEV/emc-da/1year/Andrew.Tangborn/HERA/scratch/'
#exp_name = 'exp_apr2021_jun_stddev10_C96_C192'
#exp_name  = 'exp_feb2021_feb_stddev1_inf'
exp_name = 'aerob_april_2021_rs20'
year = 2021
month = 4 
#day_list = [13,14]#,19,20,21,22,23,24] 
day_list = [3]#,14,15,16]#,17,18,19,20,21,22,23,24,25,26,27]
hour_list = [0,6,12,18]
#hour = 6
ncyc=len(day_list)*len(hour_list)-1 
mean_omf_all = np.zeros(ncyc+1)
std_omf_all = np.zeros(ncyc+1)
mean_oma_all = np.zeros(ncyc+1)
std_oma_all = np.zeros(ncyc+1)
mean_omf_all_npp = np.zeros(ncyc+1)
std_omf_all_npp = np.zeros(ncyc+1)
mean_oma_all_npp = np.zeros(ncyc+1)
std_oma_all_npp = np.zeros(ncyc+1)
cyc_num = np.zeros(ncyc+1) 

my_env = os.environ.copy()
my_env['OMP_NUM_THREADS'] = '4' # for openmp to speed up fortran call

#icyc=0
#mean_omf = []
#mean_oma = [] 
#std_omf = []
#std_oma = [] 

#if exp_name == 'cntrl_pass':
#  qc_flag = 13
#else:
#  qc_flag = 0

cmd_mk = 'mkdir '+exp_name
proc = sp.Popen(cmd_mk,env=my_env,shell=True,stdout=sp.PIPE)
time.sleep(15)
os.chdir(exp_name)
current_working_directory = os.getcwd()
print('directory = ',current_working_directory)
for day in day_list: 
   for hour in hour_list:
      print('hour = ', hour) 
      chem_path = datapath+'/'+exp_name+'/'+str(year)+str(month).zfill(2)+str(day).zfill(2)+str(hour).zfill(2)
      extract_file = ' gdas.'+str(year)+str(month).zfill(2)+str(day).zfill(2)+'/'+str(hour).zfill(2)+'/analysis/chem/gdas.t'+str(hour).zfill(2)+'z.aerostat'
      print('extract_file=',extract_file)
      print('chem_path= ',chem_path)
      tar_file = chem_path+'/gdas.tar'
      print('tar_file=',tar_file)
# Check if tar file exists
#      myfile_tar = Path(tar_file)
#      if myfile_tar.exists():
# Determine path to tar diag file  
#      proc = sp.Popen(cmd_cd,env=my_env,shell=True,stdout=sp.PIPE)
      cmd = 'htar -xvf '+tar_file+extract_file
      print(' cmd = ', cmd) 
      proc = sp.Popen(cmd,env=my_env,shell=True,stdout=sp.PIPE)
      output = proc.stdout.read()
      len1 = int(len(output)/2)
      output1 = output[0:len1]
      print('output1=',output)
            
         

